# FreeMinds HUB

This is a React + Firebase-based video platform styled like Pornhub.

## Features
- Dark theme
- Video uploads (admin)
- Video playback
- Ad slots

## Setup
1. `npm install`
2. `npm start`
